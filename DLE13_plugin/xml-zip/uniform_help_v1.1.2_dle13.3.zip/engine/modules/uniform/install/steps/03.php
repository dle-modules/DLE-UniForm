<?php
/*
 * DLE UniForm — унверсальные формы для DLE
 *
 * @author     ПафНутиЙ <pafnuty10@gmail.com>
 * @link       http://pafnuty.name/
 * @link       https://twitter.com/pafnuty_name
 */

return [

	// Заголовок шага
	'header' => 'Настройка',

	// Текст с описанием шага шага
	'text' => 'Для настройки формы ознакомьтесь с инструкциями на сайте <a href="http://pafnuty.name/modules/159-uniform.html" target="_blank">pafnuty.name</a>, это довольно простая процедура, но требует навыков.'
];
