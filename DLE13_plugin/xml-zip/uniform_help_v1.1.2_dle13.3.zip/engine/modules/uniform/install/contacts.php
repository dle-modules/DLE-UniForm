<?php
/*
 * DLE UniForm — унверсальные формы для DLE
 *
 * @author     ПафНутиЙ <pafnuty10@gmail.com>
 * @link       http://pafnuty.name/
 * @link       https://twitter.com/pafnuty_name
 */

$contacts = '
<a href="http://pafnuty.name/modules/159-uniform.html" target="_blank">Подробная информация о модуле</a> <br>
<a href="https://github.com/dle-modules/DLE-UniForm" target="_blank">Репозиторий модуля</a><br>
<a href="https://github.com/dle-modules/DLE-UniForm/issues/new" target="_blank">Сообщение в техподдержку</a><br>
Email для связи: <a href="mailto:pafnuty10@gmail.com">pafnuty10@gmail.com</a><br>
';


return $contacts;
