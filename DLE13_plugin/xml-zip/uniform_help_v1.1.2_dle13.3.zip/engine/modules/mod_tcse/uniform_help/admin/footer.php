<?php
if (!defined('DATALIFEENGINE') || !defined('LOGGED_IN')) {
    die('Hacking attempt!');
}
?>



<div class="panel">
	<div class="panel-content">
		<div class="panel-body">
			&copy; 2018 Модуль <b>uniform_help</b> — Справочная информация модуля DLE-Uniform<br>
			Версия <b>1.1.2</b> от <b>2019-10-24</b><br>
			Разработано в <a href="http://tcse-cms.com" target="_blank">TCSE-cms.com</a>
		</div>
	</div>
</div>
